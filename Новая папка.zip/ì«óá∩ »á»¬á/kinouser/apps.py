from django.apps import AppConfig


class KinouserConfig(AppConfig):
    name = 'kinouser'
